<?php
$con=mysqli_connect("localhost","root","","taxigo1");
session_start();
?>