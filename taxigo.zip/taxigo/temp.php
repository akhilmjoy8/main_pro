<?php
$d =Date();

$t = $d.getTime();
echo(t);

?>